import React from 'react';
import {View, StyleSheet} from 'react-native';

const Swiper = () => {
  return <View style={styles.container}></View>;
};

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
    backgroundColor: 'darkgrey',
    height: 150,
  },
});

export default Swiper;
